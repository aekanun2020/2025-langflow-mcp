"""
MSSQL MCP Server - No longer needed for routes
Routes are now directly in main.py
"""
