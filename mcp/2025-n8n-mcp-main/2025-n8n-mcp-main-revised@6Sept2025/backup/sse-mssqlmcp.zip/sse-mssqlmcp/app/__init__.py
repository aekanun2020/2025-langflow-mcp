"""
MSSQL MCP Server Application Package
"""
